﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RohitHansda.Data;
using RohitHansda.Models;

namespace RohitHansda.Controllers
{
    public class ProductModelsController : Controller
    {
        private readonly RohitHansdaContext _context;

        public ProductModelsController(RohitHansdaContext context)
        {
            _context = context;
        }

        // GET: ProductModels
        public async Task<IActionResult> Index()
        {
              return View(await _context.ProductModel.ToListAsync());
        }

        // GET: ProductModels/Details/5
       
        public IActionResult Create()
        {
            return View();
        }

        // POST: ProductModels/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("_name,_productCode,_brandName,_stockLeft,_price,_expiryDate")] ProductModel productModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(productModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(productModel);
        }

       
        private bool ProductModelExists(string id)
        {
          return _context.ProductModel.Any(e => e._productCode == id);
        }
    }
}
