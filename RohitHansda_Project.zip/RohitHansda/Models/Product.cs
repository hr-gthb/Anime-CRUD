﻿using System;
using System.Collections.Generic;

namespace RohitHansda.Models
{
    public partial class Product
    {
        public string? Name { get; set; }
        public string ProductCode { get; set; } = null!;
        public string? BrandName { get; set; }
        public int? StockLeft { get; set; }
        public decimal? Price { get; set; }
        public DateTime? ExpiryDate { get; set; }
    }
}
