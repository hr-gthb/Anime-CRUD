﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RohitHansda.Models
{
    [Table("Product")]
    public class ProductModel
    {
        public string? _name { get; set; }

        [Key]
        public string? _productCode { get; set; }
        public string _brandName { get; set; }
        public int _stockLeft { get; set; }
        public decimal? _price { get; set; }
        public DateTime _expiryDate { get; set; }

    }
}
