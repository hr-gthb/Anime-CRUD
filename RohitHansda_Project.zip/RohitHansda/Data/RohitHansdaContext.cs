﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RohitHansda.Models;

namespace RohitHansda.Data
{
    public class RohitHansdaContext : DbContext
    {
        public RohitHansdaContext (DbContextOptions<RohitHansdaContext> options)
            : base(options)
        {
        }

        public DbSet<RohitHansda.Models.ProductModel> ProductModel { get; set; } = default!;
    }
}
